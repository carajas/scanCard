//
//  Generated file. Do not edit.
//

#import "GeneratedPluginRegistrant.h"

#if __has_include(<core_card_io/CoreCardIoPlugin.h>)
#import <core_card_io/CoreCardIoPlugin.h>
#else
@import core_card_io;
#endif

@implementation GeneratedPluginRegistrant

+ (void)registerWithRegistry:(NSObject<FlutterPluginRegistry>*)registry {
  [CoreCardIoPlugin registerWithRegistrar:[registry registrarForPlugin:@"CoreCardIoPlugin"]];
}

@end
